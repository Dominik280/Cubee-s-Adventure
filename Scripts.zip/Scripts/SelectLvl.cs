﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class SelectLvl : MonoBehaviour
{
    public void LoadLvl1() { SceneManager.LoadScene("lvl1"); }
    public void LoadLvl2() { SceneManager.LoadScene("lvl2"); }
    public void LoadLvl3() { SceneManager.LoadScene("lvl3"); }
    public void LoadLvl4() { SceneManager.LoadScene("lvl4"); }
    public void LoadLvlB1() { SceneManager.LoadScene("lvl5"); }
    public void LoadLvl6() { SceneManager.LoadScene("lvl6"); }
    public void LoadLvl7() { SceneManager.LoadScene("lvl7"); }
    public void LoadLvl8() { SceneManager.LoadScene("lvl8"); }
    public void LoadLvl9() { SceneManager.LoadScene("lvl9"); }
    public void LoadLvlB2() { SceneManager.LoadScene("lvl10"); }
    public void LoadLvl11() { SceneManager.LoadScene("lvl11"); }
    public void LoadLvl12() { SceneManager.LoadScene("lvl12"); }
    public void LoadLvl13() { SceneManager.LoadScene("lvl13"); }
    public void LoadLvl14() { SceneManager.LoadScene("lvl14"); }
    public void LoadLvlB3() { SceneManager.LoadScene("lvl15"); }
    public void LoadLvl16() { SceneManager.LoadScene("lvl16"); }
    public void LoadLvl17() { SceneManager.LoadScene("lvl17"); }
    public void LoadLvl18() { SceneManager.LoadScene("lvl18"); }
    public void LoadLvl19() { SceneManager.LoadScene("lvl19"); }
    public void LoadLvlB4() { SceneManager.LoadScene("lvl20"); }

}
